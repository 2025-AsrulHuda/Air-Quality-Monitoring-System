from flask import Flask, render_template, request, jsonify
from geocode_and_scan import scan_place
import random

app = Flask(__name__)

# 📝 Store AQI values of scanned cities
city_aqi_memory = {}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/scan")
def api_scan():
    place = request.args.get("place")
    age = int(request.args.get("age", 25))
    condition = request.args.get("condition", "normal")
    if not place:
        return jsonify({"error": "No place given"})
    data = scan_place(place, age, condition)

    # ✅ Store scanned city AQI for news generation
    if data and "pm25" in data and data["pm25"] != "No data":
        city_aqi_memory[place] = data["pm25"]

    return jsonify(data)

# 🌍 Global leaderboard route
@app.route("/api/leaderboard")
def api_leaderboard():
    cities = ["Delhi", "Beijing", "Mumbai", "New York", "London", "Paris", "Sydney", "Tokyo", "Dubai", "Los Angeles"]
    results = []
    for c in cities:
        try:
            data = scan_place(c)
            if data and data["pm25"] != "No data":
                results.append(data)
        except:
            continue
    results = sorted(results, key=lambda x: x["pm25"] if isinstance(x["pm25"], (int, float)) else 9999)
    return {"leaderboard": results}

# 📰 AI-Generated Environmental News Feed
@app.route("/api/news")
def api_news():
    news_items = []

    if not city_aqi_memory:
        return jsonify(["No AQI data yet. Please scan some cities first."])

    for city, today_aqi in city_aqi_memory.items():
        # simulate yesterday's AQI for comparison
        yesterday_aqi = today_aqi + random.uniform(-20, 20)
        change = today_aqi - yesterday_aqi
        percent_change = (abs(change) / max(abs(yesterday_aqi), 1)) * 100

        if change < -5:
            news_items.append(
                f"🟢 {city}'s air improved by {percent_change:.1f}% since yesterday — cleaner air today!"
            )
        elif change > 5:
            news_items.append(
                f"🔴 {city}'s air worsened by {percent_change:.1f}% since yesterday — stay cautious outdoors."
            )
        else:
            news_items.append(
                f"🟡 {city}'s air quality remained stable today with minimal changes."
            )

    return jsonify(news_items)

if __name__ == "__main__":
    app.run(debug=True)
