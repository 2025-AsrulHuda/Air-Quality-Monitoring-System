from geocode_and_scan import scan_place, HASSAN_LOCATIONS

for name in HASSAN_LOCATIONS:
    result = scan_place(name)
    print(result)
