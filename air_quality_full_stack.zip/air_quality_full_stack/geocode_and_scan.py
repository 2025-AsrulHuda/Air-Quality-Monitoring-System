import requests

def geocode_place(place):
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": place, "format": "json"}
    resp = requests.get(url, params=params, timeout=10, headers={"User-Agent": "air-quality-app"})
    data = resp.json()
    if not data:
        return None, None
    return float(data[0]["lat"]), float(data[0]["lon"])

def fetch_air_quality(lat, lon):
    url = "https://air-quality-api.open-meteo.com/v1/air-quality"
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "pm2_5",
        "past_days": 1,
        "forecast_days": 1
    }
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    if "hourly" not in data or "pm2_5" not in data["hourly"]:
        return None
    return {
        "timestamps": data["hourly"]["time"],
        "pm25_values": data["hourly"]["pm2_5"]
    }

def classify_aqi(pm25):
    if pm25 <= 12: return "Good", 0
    elif pm25 <= 35.4: return "Moderate", 1
    elif pm25 <= 55.4: return "Unhealthy for Sensitive Groups", 2
    elif pm25 <= 150.4: return "Unhealthy", 3
    elif pm25 <= 250.4: return "Very Unhealthy", 4
    else: return "Hazardous", 5

def personalized_advice(aqi_label, age, condition):
    advice = ""
    if aqi_label in ["Good", "Moderate"]:
        advice = "Air quality is acceptable. Outdoor activities are safe."
    elif aqi_label == "Unhealthy for Sensitive Groups":
        advice = "Sensitive groups should limit outdoor activities. Consider wearing a mask if you go outside."
    elif aqi_label == "Unhealthy":
        advice = "Air quality is unhealthy. Avoid long outdoor activities. Exercise indoors instead."
    elif aqi_label == "Very Unhealthy":
        advice = "Very unhealthy air. Stay indoors with windows closed. Use air purifiers if available."
    else:
        advice = "Hazardous air! Stay indoors and avoid outdoor exposure completely."

    if condition == "asthma":
        advice += " Asthma patients should carry inhalers and avoid high-traffic areas."
    if condition == "child" and age < 12:
        advice += " Children should minimize outdoor play, especially in the afternoon."
    if condition == "elderly" and age > 60:
        advice += " Elderly people should avoid exertion and outdoor walking."
    if aqi_label in ["Unhealthy", "Very Unhealthy", "Hazardous"]:
        advice += " Wearing N95 masks is recommended when stepping outside."

    return advice

def scan_place(place, age=25, condition="normal"):
    lat, lon = geocode_place(place)
    if not lat:
        return {"error": "Place not found"}
    aq_data = fetch_air_quality(lat, lon)
    if not aq_data:
        return {"place": place, "pm25": "No data", "aqi_label": "Unknown", "aqi_category": -1,
                "lat": lat, "lon": lon, "advice": "", "history": {}}

    latest_pm25 = aq_data["pm25_values"][-1]
    aqi_label, aqi_category = classify_aqi(latest_pm25)
    advice = personalized_advice(aqi_label, age, condition)

    return {
        "place": place,
        "lat": lat,
        "lon": lon,
        "pm25": latest_pm25,
        "aqi_label": aqi_label,
        "aqi_category": aqi_category,
        "advice": advice,
        "history": aq_data
    }
